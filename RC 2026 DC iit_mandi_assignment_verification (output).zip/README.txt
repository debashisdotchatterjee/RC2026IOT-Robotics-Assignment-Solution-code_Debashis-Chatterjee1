IIT Mandi RC 2026 / assignment numerical verification

The numerical material checks Q4, Q7, Q14 and Q15; Q17 uses SYNTHETIC data, not supplied measurements.
Q14(b) is unstable. NEVER present formal Type-2 constants as valid final values.

